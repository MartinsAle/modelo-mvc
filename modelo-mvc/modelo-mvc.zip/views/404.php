<div class="container">
  <div class="py-5 text-center">
    <img class="d-block mx-auto mb-4" src="https://getbootstrap.com/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
    <h2>ERRO 404</h2>
    <p class="lead">A p�gina que voc� procura n�o foi encontrada!</p>
    <a href="index/">Voltar para a home</a><br>
    <a href="index/">Ir para a p�gina de contato</a>
  </div>
</div>